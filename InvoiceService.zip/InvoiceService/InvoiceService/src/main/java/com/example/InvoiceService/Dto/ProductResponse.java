package com.example.InvoiceService.Dto;

import lombok.Data;

@Data
public class ProductResponse {
    private String productId;
    private String productName;
    private int quantity;
    private double unitPrice;
}
