package com.example.InvoiceService.Controller;

import com.example.InvoiceService.Service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/invoice")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @GetMapping("/{orderId}/{productId}")
    public ResponseEntity<?> generateInvoice(
            @PathVariable String orderId,
            @PathVariable String productId) {
        try {
            // Generate and save the invoice
            String filePath = invoiceService.generateAndSaveInvoice(orderId, productId);

            // Return the file path in the response
            return ResponseEntity.ok(
                    Map.of(
                            "statusCode", 200,
                            "statusMessage", "Invoice saved successfully",
                            "filePath", filePath
                    )
            );
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(
                    Map.of(
                            "statusCode", 500,
                            "statusMessage", "Error generating or saving invoice",
                            "error", e.getMessage()
                    )
            );
        }
    }
}
