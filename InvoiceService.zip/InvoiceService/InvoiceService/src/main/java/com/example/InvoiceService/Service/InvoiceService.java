package com.example.InvoiceService.Service;

import com.example.InvoiceService.Dto.OrderResponse;
import com.example.InvoiceService.Dto.ProductResponse;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class InvoiceService {

    private final WebClient webClient;

    public InvoiceService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build(); // API Gateway URL
    }

    public OrderResponse fetchOrderDetails(String orderId) {
        try {
            return webClient.get()
                    .uri("SALESMANAGEMENT/sales/order/{id}", orderId)
                    .retrieve()
                    .bodyToMono(OrderResponse.class)
                    .block();
        } catch (WebClientResponseException e) {
            throw new RuntimeException("Failed to fetch order details: " + e.getResponseBodyAsString());
        }
    }

    public ProductResponse fetchProductDetails(String productId) {
        try {
            return webClient.get()
                    .uri("/PURCHASEMANAGEMENT/product/{id}", productId)
                    .retrieve()
                    .bodyToMono(ProductResponse.class)
                    .block();
        } catch (WebClientResponseException e) {
            throw new RuntimeException("Failed to fetch product details: " + e.getResponseBodyAsString());
        }
    }

    public String generateAndSaveInvoice(String orderId, String productId) {
        OrderResponse order = fetchOrderDetails(orderId);
        ProductResponse product = fetchProductDetails(productId);

        // Define the directory and file name for the PDF
        String directory = "C:/saved-invoices/"; // Adjust the path as needed
        String fileName = "Invoice_" + orderId + ".pdf";
        String filePath = directory + fileName;

        try {
            // Ensure the directory exists
            Files.createDirectories(Paths.get(directory));

            // Create a FileOutputStream to save the PDF
            try (FileOutputStream fileOutputStream = new FileOutputStream(filePath);
                 PdfWriter writer = new PdfWriter(fileOutputStream);
                 Document document = new Document(new com.itextpdf.kernel.pdf.PdfDocument(writer))) {

                // Write content to the PDF
                document.add(new Paragraph("Invoice Report"));
                document.add(new Paragraph("==================================="));
                document.add(new Paragraph("Order Details"));
                document.add(new Paragraph("Customer Name: " + order.getCustomerName()));
                document.add(new Paragraph("Product Name " + order.getProductName()));
                document.add(new Paragraph("Customer ID: " + order.getCustomerId()));
                document.add(new Paragraph("Product ID: " + order.getProductId())); // Fetch from OrderResponse
                document.add(new Paragraph("Quantity: " + order.getQuantity()));
                document.add(new Paragraph("Order Date: " + order.getOrderDate()));// Fetch from OrderResponse
                document.add(new Paragraph("Order Status: " + order.getStatus())); // Fetch from OrderResponse
                document.add(new Paragraph("==================================="));
                document.add(new Paragraph("Product Details"));
                document.add(new Paragraph("Product ID: " + product.getProductId()));
                document.add(new Paragraph("Product Name: " + product.getProductName())); // Fetch from ProductResponse
                document.add(new Paragraph("Price per Unit: $" + product.getUnitPrice())); // Fetch from ProductResponse
                document.add(new Paragraph("Available Quantity: " + product.getQuantity())); // Fetch from ProductResponse
                document.add(new Paragraph("==================================="));
            }

            // Return the file path
            return filePath;
        } catch (Exception e) {
            throw new RuntimeException("Error generating and saving the invoice: " + e.getMessage(), e);
        }
    }
}
