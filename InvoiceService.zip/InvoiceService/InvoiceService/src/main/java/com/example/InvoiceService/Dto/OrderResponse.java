package com.example.InvoiceService.Dto;

import lombok.Data;

import java.util.Date;

@Data
public class OrderResponse {
    private String customerName;
    private String ProductName;
    private String productId;
    private int quantity;
    private String status;
    private String customerId;
    private Date orderDate;
}
