package com.example.SalesManagement.controller;

import com.example.SalesManagement.dto.OrderRequestDTO;
import com.example.SalesManagement.Model.Order;
import com.example.SalesManagement.service.SalesService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sales")
public class SalesController {

    private final SalesService salesService;

    public SalesController(SalesService salesService) {
        this.salesService = salesService;
    }

    @PostMapping("/order")
    public ResponseEntity<Order> placeOrder(@RequestBody OrderRequestDTO orderRequest) {
        Order order = salesService.createOrderWithProductUpdate(orderRequest); // Updated to include product update
        return ResponseEntity.ok(order); // Return the created order
    }

    @PutMapping("/order/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable String id, @RequestBody OrderRequestDTO orderRequest) {
        Order updatedOrder = salesService.updateOrder(id, orderRequest);
        return ResponseEntity.ok(updatedOrder); // Return the updated order
    }

    @DeleteMapping("/order/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable String id) {
        salesService.deleteOrder(id);
        return ResponseEntity.noContent().build(); // Return a 204 No Content response
    }

    @GetMapping("/order/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable String id) {
        Order order = salesService.getOrderById(id);
        return ResponseEntity.ok(order); // Return the order details
    }

    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = salesService.getAllOrders();
        return ResponseEntity.ok(orders); // Return the list of all orders
    }
}
