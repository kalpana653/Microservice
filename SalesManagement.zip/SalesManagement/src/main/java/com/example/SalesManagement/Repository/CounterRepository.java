package com.example.SalesManagement.Repository;

import com.example.SalesManagement.Model.Counter;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CounterRepository extends MongoRepository<Counter, String> {
}
