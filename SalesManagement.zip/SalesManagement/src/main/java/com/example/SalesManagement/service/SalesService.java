package com.example.SalesManagement.service;

import com.example.SalesManagement.dto.OrderRequestDTO;
import com.example.SalesManagement.Model.Order;
import com.example.SalesManagement.Model.SalesTransaction;
import com.example.SalesManagement.Repository.SalesRepository;
import com.example.SalesManagement.Repository.OrderRepository;
import com.example.SalesManagement.dto.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class SalesService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private SalesRepository salesTransactionRepository;

    @Autowired
    private CounterService counterService; // Inject CounterService for auto-increment logic

    private final WebClient webClient;

    public SalesService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080/PURCHASEMANAGEMENT") // Update with Purchase Service URL
                .build();
    }

    @Transactional
    public Order createOrderWithProductUpdate(OrderRequestDTO orderRequest) {
        // Fetch product details from Purchase Service
        Product product = webClient.get()
                .uri("/product/" + orderRequest.getProductId())
                .retrieve()
                .bodyToMono(Product.class)
                .block(); // Blocking call to get product details

        if (product == null || product.getQuantity() < orderRequest.getQuantity()) {
            throw new IllegalArgumentException("Product not available or insufficient stock.");
        }

        // Create the order
        Order order = new Order();
        order.setOrderId(counterService.getNextSequenceId("ORDER_COUNTER")); // Auto-incremented orderId
        order.setCustomerName(orderRequest.getCustomerName());
        order.setCustomerId(orderRequest.getCustomerId());
       order.setProductName(product.getProductName());
        order.setProductId(product.getProductId());
        order.setQuantity(orderRequest.getQuantity());
        order.setOrderDate(orderRequest.getOrderDate());
        order.setStatus(orderRequest.getStatus());
        orderRepository.save(order);

        // Update product stock in Purchase Service
        webClient.post()
                .uri("/product/reduce-stock/" + product.getProductId() + "/" + orderRequest.getQuantity())
                .retrieve()
                .bodyToMono(Void.class)
                .block(); // Blocking call to reduce stock

        // Create a sales transaction
        SalesTransaction transaction = new SalesTransaction();
        transaction.setOrderId(String.valueOf(order.getOrderId()));
        transaction.setCustomerName(orderRequest.getCustomerName());
        transaction.setProductName(product.getProductName());
        transaction.setQuantity(orderRequest.getQuantity());
        transaction.setTotalPrice(orderRequest.getQuantity() * product.getUnitPrice()); // Calculate total price
        transaction.setTransactionTime(java.time.LocalDateTime.now());
        salesTransactionRepository.save(transaction);

        // Return the created order
        return order;
    }
    public String generateOrderId() {
        return "ORDER-" + UUID.randomUUID().toString();
    }

    // Create a new order
    public Order createOrder(OrderRequestDTO orderRequest) {
        Order order = new Order();
        order.setOrderId(counterService.getNextSequenceId("ORDER_COUNTER"));
        order.setCustomerName(orderRequest.getCustomerName());
        order.setProductId(orderRequest.getProductId());
        order.setQuantity(orderRequest.getQuantity());
        order.setOrderDate(orderRequest.getOrderDate());
        order.setStatus(orderRequest.getStatus());
        return orderRepository.save(order); // Save and return the created order
    }

    // Update an existing order
    public Order updateOrder(String id, OrderRequestDTO orderRequest) {
        Optional<Order> optionalOrder = orderRepository.findById(id);
        if (optionalOrder.isEmpty()) {
            throw new RuntimeException("Order not found with ID: " + id); // Handle error if order is not found
        }

        Order order = optionalOrder.get();
        order.setCustomerName(orderRequest.getCustomerName());
        order.setProductId(orderRequest.getProductId());
        order.setQuantity(orderRequest.getQuantity());
        order.setOrderDate(orderRequest.getOrderDate());
        order.setStatus(orderRequest.getStatus());
        return orderRepository.save(order); // Save and return the updated order
    }

    // Delete an order by ID
    public void deleteOrder(String id) {
        if (!orderRepository.existsById(id)) {
            throw new RuntimeException("Order not found with ID: " + id); // Handle error if order is not found
        }
        orderRepository.deleteById(id); // Delete the order
    }

    // Get order details by ID
    public Order getOrderById(String id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + id)); // Handle error if order is not found
    }

    // Get all orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll(); // Return a list of all orders
    }
}
