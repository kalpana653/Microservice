package com.example.SalesManagement.service;

import com.example.SalesManagement.Model.Counter;
import com.example.SalesManagement.Repository.CounterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CounterService {

    @Autowired
    private CounterRepository counterRepository;

    // Fetch next sequence ID
    public long getNextSequenceId(String sequenceName) {
        // Check if the counter exists for the given sequence name
        Counter counter = counterRepository.findById(sequenceName).orElse(null);

        if (counter == null) {
            // If it doesn't exist, create a new counter
            counter = new Counter(sequenceName, 1);
            counterRepository.save(counter);
        } else {
            // If it exists, increment the counter value
            counter.setSeq(counter.getSeq() + 1);
            counterRepository.save(counter);
        }

        return counter.getSeq();
    }
}
