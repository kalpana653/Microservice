package com.example.SalesManagement.Repository;
import com.example.SalesManagement.Model.SalesTransaction;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SalesRepository extends MongoRepository<SalesTransaction, String> {
}
