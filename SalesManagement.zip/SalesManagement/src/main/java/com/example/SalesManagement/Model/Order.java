package com.example.SalesManagement.Model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Getter
@Document(collection = "orders")
public class Order {
    // Getters and Setters
    @Setter
    @Id
    private String id; // MongoDB-generated ID
    @Setter
    private long orderId;
    @Setter
    private String customerId;// Unique Order ID
    @Setter
    private String customerName;
    @Setter
    private String productId;
    @Setter
    private String productName;
    @Setter
    private int quantity;

    // Define this setter
    @Setter
    private Date orderDate; // Add this field
    @Setter
    private String status;

}
