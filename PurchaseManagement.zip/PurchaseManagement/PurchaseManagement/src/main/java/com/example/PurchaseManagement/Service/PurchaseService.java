package com.example.PurchaseManagement.Service;

import com.example.PurchaseManagement.dto.SupplierOrderDTO;
import com.example.PurchaseManagement.Model.Product;
import com.example.PurchaseManagement.Model.SupplierDetails;
import com.example.PurchaseManagement.Repository.ProductRepository;
import com.example.PurchaseManagement.Repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PurchaseService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;

    public PurchaseService(ProductRepository productRepository, SupplierRepository supplierRepository) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
    }

    public void addSupplierOrder(SupplierOrderDTO order) {
        // Log to check if the order is coming in correctly
        System.out.println("Received Order: " + order);

        // Save the supplier order
        SupplierDetails supplierDetails = new SupplierDetails();
        supplierDetails.setSupplierId(Integer.parseInt(order.getSupplierId()));
        supplierDetails.setProductId(order.getProductId());
        supplierDetails.setProductName(order.getProductName());

        // Ensure that the price is not zero and is correctly set
        double price = order.getPrice();
        if (price <= 0) {
            throw new RuntimeException("Invalid price: " + price);
        }
        supplierDetails.setTotalPrice(price); // Set the total price

        supplierDetails.setQuantity(order.getQuantity());
        supplierRepository.save(supplierDetails);

        // Update or create product entry
        Optional<Product> existingProduct = productRepository.findById(order.getProductId());

        Product product;
        if (existingProduct.isPresent()) {
            product = existingProduct.get();
            // Calculate new unit price using weighted average
            double totalCostBefore = product.getUnitPrice() * product.getQuantity();
            double totalCostNew = order.getPrice();
            int totalQuantityNew = product.getQuantity() + order.getQuantity();

            double newUnitPrice = (totalCostBefore + totalCostNew) / totalQuantityNew;

            product.setUnitPrice(newUnitPrice);
            product.setQuantity(totalQuantityNew);
        } else {
            // If the product doesn't exist, create a new product
            product = new Product();
            product.setProductId(order.getProductId());
            product.setProductName(order.getProductName());

            // Calculate unit price if price and quantity are valid
            if (order.getQuantity() > 0) {
                product.setUnitPrice(order.getPrice() / order.getQuantity());
            } else {
                product.setUnitPrice(0); // If quantity is zero, set unit price to 0
            }

            product.setQuantity(order.getQuantity());
        }

        productRepository.save(product);
    }

    public SupplierDetails getSupplierOrderById(String supplierId) {
        return supplierRepository.findById(supplierId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + supplierId));
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(String productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + productId));
    }

    public void reduceStock(String productId, int quantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + productId));

        if (product.getQuantity() < quantity) {
            throw new RuntimeException("Insufficient stock for product: " + productId);
        }

        product.setQuantity(product.getQuantity() - quantity);
        productRepository.save(product);
    }

}
