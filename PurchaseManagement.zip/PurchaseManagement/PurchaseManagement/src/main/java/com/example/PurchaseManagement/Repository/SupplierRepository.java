package com.example.PurchaseManagement.Repository;

import com.example.PurchaseManagement.Model.SupplierDetails;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SupplierRepository extends MongoRepository<SupplierDetails, String> {

}
