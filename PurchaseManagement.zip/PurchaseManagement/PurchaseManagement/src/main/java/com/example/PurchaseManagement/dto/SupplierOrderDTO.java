package com.example.PurchaseManagement.dto;

import lombok.Data;

@Data
public class SupplierOrderDTO {
    private String SupplierId;
    private String productId;
    private String productName;
    private double price;
    private int quantity;
}
