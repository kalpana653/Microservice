package com.example.PurchaseManagement.Controller;

import com.example.PurchaseManagement.Model.Product;
import com.example.PurchaseManagement.Model.SupplierDetails;
import com.example.PurchaseManagement.dto.SupplierOrderDTO;
import com.example.PurchaseManagement.Service.PurchaseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
public class PurchaseController {

    private final PurchaseService purchaseService;

    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }


    @PostMapping("/supplier-order")
    public String addSupplierOrder(@RequestBody SupplierOrderDTO order) {
        purchaseService.addSupplierOrder(order);
        return "Order added and product stock updated.";
    }
    @GetMapping("/supplier-order/{supplierId}")
    public ResponseEntity<SupplierDetails> getSupplierOrderById(@PathVariable String supplierId) {
        SupplierDetails order = purchaseService.getSupplierOrderById(supplierId);
        return ResponseEntity.ok(order);
    }
    //Productss
    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable String id) {
        Product product = purchaseService.getProductById(id);
        return ResponseEntity.ok(product);
    }
    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(purchaseService.getAllProducts());
    }
    @PostMapping("/product/reduce-stock/{id}/{quantity}")
    public ResponseEntity<Void> reduceStock(@PathVariable String id, @PathVariable int quantity) {
        purchaseService.reduceStock(id, quantity);
        return ResponseEntity.ok().build();
    }

}
