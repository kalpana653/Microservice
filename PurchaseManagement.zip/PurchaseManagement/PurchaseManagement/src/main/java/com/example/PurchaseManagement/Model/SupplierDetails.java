package com.example.PurchaseManagement.Model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@Document(collection = "supplier_details")
public class SupplierDetails {
    @Id
    private int supplierId; // Primary key
    private String supplierName;
    private String productName;
    private String productId;
    private int quantity;
    private double totalPrice;
}
