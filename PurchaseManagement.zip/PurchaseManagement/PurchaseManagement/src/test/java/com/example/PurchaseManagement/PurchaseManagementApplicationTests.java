package com.example.PurchaseManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurchaseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
