//package com.example.Report_Service.controller;
//
//import com.example.Report_Service.model.Report;
//import com.example.Report_Service.service.ReportService;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/reports")
//public class ReportController {
//
//    private final ReportService reportService;
//
//    // Manually add constructor
//    public ReportController(ReportService reportService) {
//        this.reportService = reportService;
//    }
//
//    @GetMapping("/generate")
//    public ResponseEntity<List<Report>> generateReport() {
//        List<Report> reports = reportService.generateCombinedReport();
//        return ResponseEntity.ok(reports);
//    }
//}
package com.example.Report_Service.controller;

import com.example.Report_Service.model.Report;
import com.example.Report_Service.service.ReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/report")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    // Endpoint to generate and fetch the sales report
    @GetMapping("/sales")
    public ResponseEntity<?> generateSalesReport() {
        try {
            List<Report> salesReports = reportService.generateSalesReport();
            return new ResponseEntity<>(
                    new ApiResponse(200, "Sales report generated successfully", salesReports),
                    HttpStatus.OK
            );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ApiResponse(500, "Error generating sales report", null),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    // Endpoint to generate and fetch the purchase report
    @GetMapping("/purchase")
    public ResponseEntity<?> generatePurchaseReport() {
        try {
            List<Report> purchaseReports = reportService.generatePurchaseReport();
            return new ResponseEntity<>(
                    new ApiResponse(200, "Purchase report generated successfully", purchaseReports),
                    HttpStatus.OK
            );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ApiResponse(500, "Error generating purchase report", null),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    // Endpoint to generate and fetch the combined report (Sales + Purchase)
    @GetMapping("/combined")
    public ResponseEntity<?> generateCombinedReport() {
        try {
            List<Report> combinedReports = reportService.generateCombinedReport();
            return new ResponseEntity<>(
                    new ApiResponse(200, "Combined report generated successfully", combinedReports),
                    HttpStatus.OK
            );
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ApiResponse(500, "Error generating combined report", null),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    // API Response Wrapper Class
    public static class ApiResponse {
        private int statusCode;
        private String statusMessage;
        private Object data;

        public ApiResponse(int statusCode, String statusMessage, Object data) {
            this.statusCode = statusCode;
            this.statusMessage = statusMessage;
            this.data = data;
        }

        // Getters and Setters
        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getStatusMessage() {
            return statusMessage;
        }

        public void setStatusMessage(String statusMessage) {
            this.statusMessage = statusMessage;
        }

        public Object getData() {
            return data;
        }

        public void setData(Object data) {
            this.data = data;
        }
    }
}
