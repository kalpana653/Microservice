package com.example.Report_Service.repository;

import com.example.Report_Service.model.Report;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReportRepository extends MongoRepository<Report, String> {
}
