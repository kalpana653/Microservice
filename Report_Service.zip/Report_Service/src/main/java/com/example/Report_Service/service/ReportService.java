//package com.example.Report_Service.service;
//
//import com.example.Report_Service.model.Report;
//import com.example.Report_Service.model.ProductReport;
//import com.example.Report_Service.model.SalesReport;
//import com.example.Report_Service.repository.ReportRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.reactive.function.client.WebClient;
//
//import java.util.List;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//
//@Service
//public class ReportService {
//    @Autowired
//    public ReportService(WebClient.Builder webClientBuilder, ReportRepository reportRepository) {
//        this.webClientBuilder = webClientBuilder;
//        this.reportRepository = reportRepository;
//    }
//    private final WebClient.Builder webClientBuilder;
//    private final ReportRepository reportRepository;
//
//    // Fetch sales data from Sales Service
//    public List<SalesReport> fetchSalesReports() {
//        WebClient webClient = webClientBuilder.build();
//        return webClient.get()
//                .uri("http://localhost:8080/SALESMANAGEMENT/sales/orders")
//                .retrieve()
//                .bodyToFlux(SalesReport.class)
//                .collectList()
//                .block();
//    }
//
//    // Fetch purchase data from Purchase Service
//    public List<ProductReport> fetchPurchaseReports() {
//        WebClient webClient = webClientBuilder.build();
//        return webClient.get()
//                .uri("http://localhost:8080/PURCHASEMANAGEMENT/products")
//                .retrieve()
//                .bodyToFlux(ProductReport.class)
//                .collectList()
//                .block();
//    }
//
//    // Generate a combined report using Streams API
//    public List<Report> generateCombinedReport() {
//        // Fetch data from both services
//        List<SalesReport> salesReports = fetchSalesReports();
//        List<ProductReport> purchaseReports = fetchPurchaseReports();
//
//        // Map Sales data to Report objects
//        List<Report> salesMappedReports = salesReports.stream()
//                .filter(sales -> sales.getStatus().equalsIgnoreCase("New")) // Filter by status
//                .map(sales -> new Report(
//                        null,
//                        "Sales",
//                        sales.getId(),
//                        sales.getCustomerName(),
//                        sales.getProductId(),
//                        null,
//                        sales.getQuantity(),
//                        0.0,
//                        sales.getStatus()
//                ))
//                .collect(Collectors.toList());
//
//        // Map Purchase data to Report objects
//        List<Report> purchaseMappedReports = purchaseReports.stream()
//                .filter(purchase -> purchase.getQuantity() > 5) // Filter by quantity
//                .map(purchase -> new Report(
//                        null,                          // ID will be auto-generated
//                        "Purchase",                    // Type
//                        purchase.getId(),              // Entity ID
//                        null,                          // No Customer Name for Purchases
//                        purchase.getProductId(),       // Product ID
//                        purchase.getProductName(),     // Product Name
//                        purchase.getQuantity(),        // Quantity
//                        purchase.getUnitPrice(),       // Unit Price
//                        null                           // No Status for Purchases
//                ))
//                .collect(Collectors.toList());
//
//        // Combine and sort reports by quantity in descending order
//        List<Report> combinedReports = Stream.concat(salesMappedReports.stream(), purchaseMappedReports.stream())
//                .sorted((r1, r2) -> Integer.compare(r2.getQuantity(), r1.getQuantity()))
//                .collect(Collectors.toList());
//
//        // Save combined reports to MongoDB
//        reportRepository.saveAll(combinedReports);
//
//        return combinedReports;
//    }
//}
package com.example.Report_Service.service;

import com.example.Report_Service.model.Report;
import com.example.Report_Service.model.ProductReport;
import com.example.Report_Service.model.SalesReport;
import com.example.Report_Service.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Service
public class ReportService {
    @Autowired
    public ReportService(WebClient.Builder webClientBuilder, ReportRepository reportRepository) {
        this.webClientBuilder = webClientBuilder;
        this.reportRepository = reportRepository;
    }
    private final WebClient.Builder webClientBuilder;
    private final ReportRepository reportRepository;

    // Fetch sales data from Sales Service
    public List<SalesReport> fetchSalesReports() {
        WebClient webClient = webClientBuilder.build();
        return webClient.get()
                .uri("http://localhost:8080/SALESMANAGEMENT/sales/orders")
                .retrieve()
                .bodyToFlux(SalesReport.class)
                .collectList()
                .block();
    }

    // Fetch purchase data from Purchase Service
    public List<ProductReport> fetchPurchaseReports() {
        WebClient webClient = webClientBuilder.build();
        return webClient.get()
                .uri("http://localhost:8080/PURCHASEMANAGEMENT/products")
                .retrieve()
                .bodyToFlux(ProductReport.class)
                .collectList()
                .block();
    }

    // Generate Sales Report with filtering, sorting, and aggregation using Streams API
    public List<Report> generateSalesReport() {
        List<SalesReport> salesReports = fetchSalesReports();

        // Filter and map Sales data to Report objects
        List<Report> salesMappedReports = salesReports.stream()
                .filter(sales -> sales.getStatus().equalsIgnoreCase("New")) // Filter by status
                .map(sales -> new Report(
                        null,
                        "Sales",
                        sales.getId(),
                        sales.getCustomerName(),
                        sales.getProductId(),
                        null,
                        sales.getQuantity(),
                        0.0,
                        sales.getStatus()
                ))
                .collect(Collectors.toList());

        // Aggregate: For example, summing up the total quantity sold
        long totalQuantitySold = salesMappedReports.stream()
                .mapToInt(Report::getQuantity)
                .sum();

        // Sorting by quantity using a custom comparator (desc)
        List<Report> sortedSalesReports = salesMappedReports.stream()
                .sorted((r1, r2) -> Integer.compare(r2.getQuantity(), r1.getQuantity())) // Sorting by quantity in descending order
                .collect(Collectors.toList());

        // Save reports to MongoDB
        reportRepository.saveAll(sortedSalesReports);

        // Return the sorted sales reports and aggregate data (you can return the aggregate if needed)
        return sortedSalesReports;
    }

    // Generate Purchase Report with filtering, sorting, and aggregation using Streams API
    public List<Report> generatePurchaseReport() {
        List<ProductReport> purchaseReports = fetchPurchaseReports();

        // Filter and map Purchase data to Report objects
        List<Report> purchaseMappedReports = purchaseReports.stream()
                .filter(purchase -> purchase.getQuantity() > 5) // Filter by quantity
                .map(purchase -> new Report(
                        null,                          // ID will be auto-generated
                        "Purchase",                    // Type
                        purchase.getId(),              // Entity ID
                        null,                          // No Customer Name for Purchases
                        purchase.getProductId(),       // Product ID
                        purchase.getProductName(),     // Product Name
                        purchase.getQuantity(),        // Quantity
                        purchase.getUnitPrice(),       // Unit Price
                        null                           // No Status for Purchases
                ))
                .collect(Collectors.toList());

        // Aggregate: For example, summing up the total stock quantity
        long totalStockPurchased = purchaseMappedReports.stream()
                .mapToInt(Report::getQuantity)
                .sum();

        // Sorting by quantity in ascending order using a different method
        List<Report> sortedPurchaseReports = purchaseMappedReports.stream()
                .sorted((r1, r2) -> Integer.compare(r1.getQuantity(), r2.getQuantity())) // Sorting by quantity in ascending order
                .collect(Collectors.toList());

        // Save reports to MongoDB
        reportRepository.saveAll(sortedPurchaseReports);

        // Return the sorted purchase reports and aggregate data (you can return the aggregate if needed)
        return sortedPurchaseReports;
    }

    // Generate Combined Report (Sales + Purchase)
    public List<Report> generateCombinedReport() {
        // Fetch sales and purchase reports
        List<Report> salesReports = generateSalesReport();
        List<Report> purchaseReports = generatePurchaseReport();

        // Combine both lists
        List<Report> combinedReports = Stream.concat(salesReports.stream(), purchaseReports.stream())
                .sorted((r1, r2) -> Integer.compare(r2.getQuantity(), r1.getQuantity())) // Sorting by quantity in descending order
                .collect(Collectors.toList());

        // Save combined reports to MongoDB
        reportRepository.saveAll(combinedReports);

        return combinedReports;
    }
}

