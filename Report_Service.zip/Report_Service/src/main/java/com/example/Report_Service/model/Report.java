package com.example.Report_Service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor

@Document(collection = "ReportsDoc")
public class Report {

    @Id
    private String id; // Unique identifier for each report
    private String type; // "Sales" or "Purchase"
    private String entityId; // Sales or Purchase ID
    private String customerName; // Relevant for Sales
    private String productId; // Product ID
    private String productName; // Relevant for Purchase
    private int quantity; // Quantity
    private double unitPrice; // Relevant for Purchase
    private String status; // Relevant for Sales ("New", etc.)

    public Report(String id, String type, String entityId, String customerName, String productId, String productName, int quantity, double unitPrice, String status) {
        this.id = id;
        this.type = type;
        this.entityId = entityId;
        this.customerName = customerName;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
